#Kira Mathias-Prabhu + kmathias + Section C
#15-112 Term Project Dec 2014
#Picture This is an application that takes in text and generates a representative
#photo collage with different sized images based on word frequency

#the stopwords list comes from http://www.ranks.nl/stopwords

import urllib2, urllib
import xml.etree.ElementTree as ET
import pyglet
from pyglet import image
from pyglet import clock
import os, random, time


class HelpWindow(pyglet.window.Window):
    def __init__(self, *args, **kwargs):
        super(HelpWindow, self).__init__(420, 500, caption='Picture This! Help')

    
    def on_draw(self):       
        self.clear()        
        self.label = pyglet.text.Label( """Welcome to Picture This! 
        Here\'s how this works: 
        1. Enter some text, or a path to a text file (.txt)
        2. Select either 'Collage from Text' or 'Collage from File'
        3. Sit back and relax. We'll turn it into a montage!
                
        Commands: 
        * ESC to exit
        * the up arrow or Help button for this help dialog
        * 'R' to restart and create a new collage
        * 'S' to save a screenshot of your collage to the
        directory "savedCollages" 
                
            That's it!""",
                          font_name='Trebuchet',
                          font_size=10,
                          x=30, y=self.height*0.8,
                          multiline=True, width=self.width-10, height=self.height*0.75) 
        self.label.draw()

            
     


class PhotoCollage(pyglet.window.Window):
    def __init__(self, *args, **kwargs):
        super(PhotoCollage, self).__init__(600, 600, caption='Picture This!')

        self.batch = pyglet.graphics.Batch()
        self.batch2 = pyglet.graphics.Batch()
        self.pathLabel = pyglet.text.Label('Enter some text, or a path to a text file', 
            x=self.width/2, y=self.height/2, anchor_x='center', anchor_y='center',
            batch=self.batch, font_name='Trebuchet')
        self.pathTextBox = TextWidget('', self.width/2-200, self.height/2 - 35, 400, self.batch)
        self.text_cursor = self.get_system_mouse_cursor('text')
        self.text = self.contents = ""
        self.focus = None
        self.set_focus(self.pathTextBox)
        self.state = 0
        self.listOfWords = []
        self.maxFreq = 0
        self.urls = []
        self.sprites = []
        if (not os.path.exists("tempDir")):
            os.makedirs("tempDir")
        self.background = pyglet.graphics.Batch()
        self.midground  = pyglet.graphics.Batch()
        self.foreground = pyglet.graphics.Batch()
        self.loadCalled = False
        self.numForeground = 0
        self.stopwords = self.readFile('TermProj/stopwords.txt')
        self.loading = pyglet.text.Label('Your collage is being generated!', 
            x=self.width/2, y=self.height/2, anchor_x='center', 
            anchor_y='center', font_name='Trebuchet', batch=self.batch2)
        self.count = 0
        self.introGraphic = pyglet.sprite.Sprite(image.load('picThis.png'), 
            self.width*0.14, self.height*0.25)
        self.introGraphic.scale = 0.2
        self.displayFileNotFound = False
        self.helpButton = Button("Help", 10, 10, 50, 30)
        self.s1FileButton = Button("Collage from file", 310, 200, 150, 30)
        self.s1TextButton = Button("Collage from text", 130, 200, 150, 30)
        self.instructions = pyglet.text.Label(
                """\tWelcome to Picture This! 
                Here\'s how this works: 
                1. Enter some text, or a path to a text file (.txt)
                2. Select either 'Collage from Text' or 'Collage from File'
                3. Sit back and relax. We'll turn it into a montage!
                
                Commands: 
                * ESC to exit
                * the up arrow or HELP button for this help dialog
                * 'R' to restart and create a new collage
                * 'S' to save a screenshot of your collage to the
                   directory "savedCollages" 
                
                        That's it!""",
                          font_name='Trebuchet',
                          font_size=14,
                          x=self.width/2+20, y=self.height/2-50, 
                          anchor_x ='center', anchor_y ='center',
                          multiline=True, width=self.width*0.75, 
                          height=self.height*0.75)
        pyglet.clock.schedule_interval(self.update, 1/60.0)

        
   ##########Game State 0#####################
    def update(self,dt):
      if self.state == 0:
            if self.introGraphic.opacity > 0:
                self.introGraphic.opacity -= 25*dt
                self.introGraphic.rotation += 10*dt 
                self.introGraphic.scale += 0.1*dt
      
   
  ############onDraw################
    def on_draw(self):

        self.clear()
        pyglet.clock.tick()
        if self.state == 0:
            batch = pyglet.graphics.Batch()
            self.helpButton.draw()            
            self.introGraphic.draw()

            if self.introGraphic.opacity <= 0:
                self.state = 1
            if self.introGraphic.opacity < 205: 
                self.instructions.draw()
    
        elif self.state == 1:
        #asking for input
            self.s1FileButton.draw()
            self.s1TextButton.draw()
            self.helpButton.draw()

            self.batch.draw()
            if self.displayFileNotFound:
                self.label.draw()
        elif self.state == 2:
        #download images, assign to batches
            self.batch2.draw()
            if not self.loadCalled:
                if self.count > 60: 
                    self.load()
                    self.loadCalled = True
                else: self.count += 1
        else:
            #display collage 
            self.background.draw()
            self.midground.draw()
            self.foreground.draw()

   
   
   
   ############### File Processing and word analysis #########

    #read file from course notes
    def readFile(self, fileName, mode="rt"):
        # rt = "read text"
        with open(fileName, mode) as fin:
            return fin.read()

    
    def wordByWord(self):
        #read word by word from file
        allWords = self.contents.split(" ")
        words = set()
        myDict = dict()
        #keep set of words, check membership in set
        for word in allWords:
            if word.lower() not in self.stopwords and word.isalpha():
                if word.lower() in words:
                    myDict[word.lower()] += 1
                else:
                #if not in set, add to set, add to dict 
                    words.add(word.lower())
                    myDict[word.lower()] = 1
    
        #sort dict by values
        #I learned this from http://stackoverflow.com/questions/613183/sort-a-python-dictionary-by-value?rq=1
        for freq in sorted(myDict, key=myDict.get, reverse=True):
            self.listOfWords.append((freq,myDict[freq]))
            self.maxFreq = self.listOfWords[0][1]
            if float(myDict[freq])/self.maxFreq > 0.75 and self.numForeground <= 4:
                self.numForeground += 1
            

        print self.listOfWords

   
    
    ######### Image processing methods #######################
 
    def getImage(self,word):
    #returns url of photo on flickr server, so image can be downloaded
        baseurl = "https://api.flickr.com/services/rest/?"
        method = "&method=flickr.photos.search&api_key=da640391182dcb70b5e0ae1fe88807ff&per_page=10"
        searchTerm = "&text=" + word

        query = baseurl + method + searchTerm


        xmlResult = urllib.urlopen(query).read()

        root = ET.fromstring(xmlResult)

        for elem in root[0].iter('photo'):
            try:
                myDict = elem.attrib
                if ('farm' in myDict and 'server' in myDict 
                and 'id' in myDict and 'secret' in myDict):
                    farm = myDict['farm']
                    server = myDict['server']
                    id = myDict['id']
                    secret = myDict['secret']
                    photoUrl = "https://farm%s.staticflickr.com/%s/%s_%s.jpg" %(farm,server,id,secret)
                    print word, photoUrl
                    return photoUrl
            except:
                continue
                

    #photo url form is
    #https://farm{farm-id}.staticflickr.com/{server-id}/{id}_{secret}.jpg
 
    def getUrls(self):
    #takes list of tuples of form (word, freq) and generates list of urls
        urlList = []
        for elem in self.listOfWords:
            word = elem[0]
            url = self.getImage(word)
            urlList.append(url)
        self.urls = urlList

#######################Step 3 Assigning batches###########

    def download(self, url, fileName):
        with open(fileName, "wb") as fp:        
            fp.write(urllib2.urlopen(url).read())


    def assignBatch(self, freq):
        freq = float(freq)
        maxFreq = float(self.maxFreq)       
        if (len(self.urls) < 10 or 
            (float)(self.listOfWords[len(self.urls)-1][1])/self.maxFreq >= 0.5):
            return self.background
        
        elif freq/maxFreq < .4:
        #background
            return self.background
        elif freq/maxFreq < 0.75:
        #midground
            return self.midground
        else:
        #foreground
            return self.foreground
        
    def saveCollage(self):
        if (not os.path.exists("savedCollages")):
            os.makedirs("savedCollages")
            num = 1
        else:
            files = os.listdir("savedCollages")
            num = len(files) + 1
        savePath = "savedCollages" + os.sep + "collage" + str(num) + ".jpg"
        pyglet.image.get_buffer_manager().get_color_buffer().save(savePath)
    
    ############## LOAD #########
    def load(self):
        self.wordByWord()
        self.maxFreq = self.listOfWords[0][1]
        self.getUrls()
        self.downloadToBatches()
            
        
    def downloadToBatches(self):
        notAssigned = True
        minHeight = self.height
        (x,y) = (0,0)
        num = 0
        while (num < len(self.urls)): 
            batch = self.assignBatch(self.listOfWords[num][1])
                
            if batch == self.background: 
                self.handleBackground(num)
                break
            elif batch == self.midground:
                fileName = "pic" + str(num) + ".jpg"
                path = "tempDir" + os.sep + fileName
                self.download(self.urls[num], path)
                print "downloading", self.urls[num]
                print "to path", path
                pic = image.load(path)
                picDim = (self.width*self.height/10)**0.5
                x = random.randint(0,self.width)
                y = random.randint(0,self.height)                
                sprite = pyglet.sprite.Sprite(pic, x, y, batch=batch)
                scale = (picDim/min(sprite.width,sprite.height))
                sprite.scale = scale
                sprite.x, sprite.y = self.checkSpriteCoords(sprite)
                num += 1
            else: num = self.handleForeground(num)
        self.state = 3    

    
    def checkSpriteCoords(self, sprite):
    #prevent images from being cropped off the screen
        if sprite.y + sprite.height >= self.height:

            sprite.y = self.height-sprite.height
        elif sprite.x + sprite.width >= self.width:
            sprite.x = self.width - sprite.width
        return (sprite.x, sprite.y)
    
    def handleBackground(self, num):
        minHeight = self.height
        numPics = len(self.urls) - num
        picDim = ((self.width*self.height)/numPics)**0.5
        notAssigned = False
        (x,y) = (0,0)
        while(num < numPics and self.urls[num] != None
        and self.assignBatch(self.listOfWords[num][1]) == self.background):
            
            fileName = "pic" + str(num) + ".jpg"
            path = "tempDir" + os.sep + fileName
            print "downloading", self.urls[num]
            print "to path", path
         
            self.download(self.urls[num], path)
            pic = image.load(path)
                        
            
            sprite = pyglet.sprite.Sprite(pic, x, y, batch=self.background)

            scale = (picDim/min(sprite.width,sprite.height))
            sprite.scale = scale
            
            sprite.x, sprite.y = self.checkSpriteCoords(sprite)
            if sprite.height < minHeight: minHeight = sprite.height
            if x+sprite.width < self.width:
                x += sprite.width
            else:
                x = 0
                y += minHeight
                minHeight = self.height
            self.sprites.append(sprite)
            num += 1
        return num    
    
    def handleForeground(self, num):        

        for file in xrange(self.numForeground):
                fileName = "pic" + str(num) + ".jpg"
                path = "tempDir" + os.sep + fileName
                print "downloading", self.urls[num]
                print "to path", path
                self.download(self.urls[num], path)
                pic = image.load(path)
                

                scaleInt = random.randint(4,8)
                picDim = (self.width*self.height/scaleInt)**0.5
                
                if (file/2) > 0: x = random.randint(int(picDim), self.width/2)
                else: x = random.randint(self.width/2, int(self.width-picDim))
                if (file%2) == 0: y = random.randint(int(picDim), self.height/2)
                else: y = random.randint(self.height/2, int(self.height-picDim))
                
                sprite = pyglet.sprite.Sprite(pic, x, y, batch=self.foreground)
                scale = (picDim/min(sprite.width,sprite.height))
                
                sprite.x, sprite.y = self.checkSpriteCoords(sprite)
                
                sprite.scale = scale
                num += 1
                self.sprites.append(sprite)
        return num
                
    
    def on_resize(self, width, height):
        super(PhotoCollage, self).on_resize(width, height)
        self.pathTextBox.width = width - 110
   

    def checkFile(self):
        print self.text
        try:
            if ".txt" in self.text:
                self.contents = self.readFile(self.text)
                self.state = 2
                self.batch2.draw()
            else: 
                self.label = pyglet.text.Label('Please choose a (.txt) file',
                        font_name='Trebuchet',
                        font_size=36,
                        x=self.width/2, y=self.height/2 - 170,
                        anchor_x='center', anchor_y='center') 
                self.displayFileNotFound = True

        except:
            self.label = pyglet.text.Label('No such file. Try again.',
                          font_name='Trebuchet',
                          font_size=36,
                          x=self.width/2, y=self.height/2 - 170,
                          anchor_x='center', anchor_y='center') 
            self.displayFileNotFound = True

    
    def restart(self):
        self.listOfWords = []
        self.maxFreq = 0
        self.urls = []
        self.sprites = []
        if (not os.path.exists("tempDir")):
            os.makedirs("tempDir")
        self.background = pyglet.graphics.Batch()
        self.midground  = pyglet.graphics.Batch()
        self.foreground = pyglet.graphics.Batch()
        self.loadCalled = False
        self.numForeground = 0
        self.loadCalled = False
        self.count = 0
            #self.text = self.focus.document.text
        self.state = 1
    
    
    #parts of this method and on_mouse_press are from pyglet docs
    #they have been modified and added to match my program's functionality
    #https://phobiax.googlecode.com/svn-history/r5/trunk/_window.py
    def on_key_press(self, symbol, modifiers):
        if symbol == pyglet.window.key.BACKSPACE:
            self.text = self.text[:-1]
            #print self.text
            if self.displayFileNotFound: self.displayFileNotFound = False
        
        if symbol == pyglet.window.key.UP:
        #help
            self.helpWindow = HelpWindow()

                    
        if symbol == pyglet.window.key.ENTER:
        #treat input as file name    
            self.checkFile()
            
        
        if symbol == pyglet.window.key.R and self.state != 1:
        #return to input screen
            self.restart()    

            
        
        if symbol == pyglet.window.key.S and self.state > 1:
        #save collage    
            self.saveCollage()
        
        if symbol == pyglet.window.key.TAB:
            if modifiers & pyglet.window.key.MOD_SHIFT:
                dir = -1
            else:
                dir = 1

            if self.focus in self.widgets:
                i = self.widgets.index(self.focus)
            else:
                i = 0
                dir = 0

            self.set_focus(self.widgets[(i + dir) % len(self.widgets)])

        elif symbol == pyglet.window.key.ESCAPE:
            pyglet.app.exit()
   
    
    
    def on_mouse_press(self, x, y, button, modifiers):        
        if self.helpButton.hit_test(x,y):
            helpWindow = HelpWindow()
            self.switch_to(helpWindow)
        
        if self.state == 1 and self.s1FileButton.hit_test(x,y):
            self.checkFile()
        
        if self.state == 1 and self.s1TextButton.hit_test(x,y):
            self.contents = self.text.encode('ascii', 'ignore')
            self.state = 2        
        if self.pathTextBox.hit_test(x, y):
            self.set_focus(self.pathTextBox)
        else:
            self.set_focus(None)

        if self.focus:
            self.focus.caret.on_mouse_press(x, y, button, modifiers)
    
    
    
    
    #### below methods up to Button class are ver batum from the pyglet docs
    #https://phobiax.googlecode.com/svn-history/r5/trunk/_window.py
    def on_mouse_motion(self, x, y, dx, dy):
        if self.pathTextBox.hit_test(x, y):
            self.set_mouse_cursor(self.text_cursor)
        else:
            self.set_mouse_cursor(None)



    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        if self.focus:
            self.focus.caret.on_mouse_drag(x, y, dx, dy, buttons, modifiers)

    def on_text(self, text):
        if self.focus:
            self.focus.caret.on_text(text)
            self.text += text

    def on_text_motion(self, motion):
        if self.focus:
            self.focus.caret.on_text_motion(motion)
      
    def on_text_motion_select(self, motion):
        if self.focus:
            self.focus.caret.on_text_motion_select(motion)

  
           
        
    def set_focus(self, focus):
        if self.focus:
            self.focus.caret.visible = False
            self.focus.caret.mark = self.focus.caret.position = 0

        self.focus = focus
        if self.focus:
            self.focus.caret.visible = True
            self.focus.caret.mark = 0
            self.focus.caret.position = len(self.focus.document.text)

#Button class is original

class Button(object):
    def __init__(self,text, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text
                                   
    
    def hit_test(self,x,y):
        return (self.x < x and self.x+self.width > x
        and self.y < y and self.y + self.height > y)
    
    def draw(self):
        pyglet.graphics.draw_indexed(4, pyglet.gl.GL_LINE_STRIP,
        [0,1,2,0,2,3], ('v2i', (self.x, self.y, 
                                self.x+self.width, self.y,
                                self.x+self.width, self.y+self.height,
                                self.x, self.y+self.height)))
        pyglet.graphics.draw_indexed(4, pyglet.gl.GL_TRIANGLES,
        [0,1,2,0,2,3], ('v2i', (self.x, self.y, 
                                self.x+self.width-1, self.y,
                                self.x+self.width-1, self.y+self.height,
                                self.x, self.y+self.height)),
                        ('c3B', [0,0,128] * 4))                
        
        label = pyglet.text.Label(self.text, 
            x=self.x+self.width/2, y=self.y+self.height/2, 
            anchor_x='center', anchor_y='center',
            font_name='Trebuchet')
        label.draw()        
    

##########Below classes are from pyglet docs 
#https://phobiax.googlecode.com/svn-history/r5/trunk/_window.py 
'''Demonstrates basic use of IncrementalTextLayout and Caret.

A simple widget-like system is created in this example supporting keyboard and
mouse focus.
'''

__docformat__ = 'restructuredtext'
__version__ = '$Id: $'

class Rectangle(object):
    '''Draws a rectangle into a batch.'''
    def __init__(self, x1, y1, x2, y2, batch):
        self.vertex_list = batch.add(4, pyglet.gl.GL_QUADS, None,
            ('v2i', [x1, y1, x2, y1, x2, y2, x1, y2]),
            ('c4B', [200, 200, 220, 255] * 4)
        )
    
   

class TextWidget(object):
    def __init__(self, text, x, y, width, batch):
        self.document = pyglet.text.document.UnformattedDocument(text)
        self.document.set_style(0, len(self.document.text), 
            dict(color=(0, 0, 0, 255))
        )
        font = self.document.get_font()
        height = font.ascent - font.descent

        self.layout = pyglet.text.layout.IncrementalTextLayout(
            self.document, width, height, multiline=False, batch=batch)
        self.caret = pyglet.text.caret.Caret(self.layout)

        self.layout.x = x
        self.layout.y = y

        # Rectangular outline
        pad = 2
        self.rectangle = Rectangle(x - pad, y - pad, 
                                   x + width + pad, y + height + pad, batch)

    def hit_test(self, x, y):
        return (0 < x - self.layout.x < self.layout.width and
                0 < y - self.layout.y < self.layout.height)        


                   
window = PhotoCollage()
pyglet.app.run()



    
        
